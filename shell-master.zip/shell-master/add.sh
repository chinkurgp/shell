#!/bin/bash

read -p "Enter two nos. :" a b 
c=$(( a + b )) 
echo "Sum of $a and $b is:" $c
