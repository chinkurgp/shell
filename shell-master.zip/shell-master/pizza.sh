#!/bin/bash

echo "Displaying pizza names"
echo "$@"
echo   

