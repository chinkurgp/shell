#!/bin/sh
echo "Hello $(whoami)"
echo "Today is $(date)"
echo "Users currently logged in:" $(who)
